# Web-Design-Project

This is a group project for a Web Design course for the university's final project. The project will be graded upon.
Owners and Contributors of this project are myself, Mohammad Sadav Imtiaz Alam and Youssef Ibrahim. 

Develop an interactive website for a local business. These are the conditions for the
website:
1. It should be an accessible website.
2. It should be responsive (the content shown to the user should be appropriate
based on the user’s device resolution).
3. The website should have at least the following pages: Home, About Us, and Contact Us.
Any other pages will be based on the business needs. For example, a restaurant’s
the website needs a page about the menu, whereas a beauty salon’s website needs a page
about the services that they offered.
4. The website should be interactive, you need JavaScript for this purpose or any of its
libraries.
5. Make sure your design matches the target audience and business needs.

The contents of this project are subject to MIT License. 
